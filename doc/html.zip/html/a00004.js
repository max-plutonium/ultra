var a00004 =
[
    [ "execute", "a00004.html#a59183c4ef7b1b6bd6acd4dd53027bcec", null ],
    [ "execute_with_delay", "a00004.html#a6bfe4990633064faf00faab87599a11c", null ],
    [ "shutdown", "a00004.html#a4555e4397489d1f4875b95637e3f8e0f", null ],
    [ "stopped", "a00004.html#a0da7a60b388e91333e34bd27df20d299", null ]
];