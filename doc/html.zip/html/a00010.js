var a00010 =
[
    [ "operator()", "a00010.html#ab69674b52c39efb85ee400788ac1b943", null ],
    [ "operator()", "a00010.html#ab9db8447ebc807e056668acd9e7aba0d", null ]
];