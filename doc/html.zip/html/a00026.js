var a00026 =
[
    [ "impl", "a00026.html#a611b3f42fa13b51aa7e37dd052f9ea08", null ],
    [ "connect_receiver", "a00026.html#a08f75ff339213efbe4938e4857340be6", null ],
    [ "connect_sender", "a00026.html#ac86ed3dcf9e5e002bbb2ea858bb0c8a5", null ],
    [ "disconnect_all_receivers", "a00026.html#ae3f009392d44a6a42933ad26a0b34255", null ],
    [ "disconnect_all_senders", "a00026.html#a758dbf012e53a8f445398878eb1f2093", null ],
    [ "disconnect_receiver", "a00026.html#a10abaab1168de5b11f09bd7515c60b0a", null ],
    [ "disconnect_sender", "a00026.html#a99e9ceebc59f5839f31cf872cb224ae4", null ],
    [ "on_message", "a00026.html#aabc55f9e548d84fe6e046f98b7d0b6f5", null ],
    [ "xsputn", "a00026.html#a1e93eb78b750180a44b185f0610a3485", null ],
    [ "_om", "a00026.html#a19634ac2d52fa9eccc66d49b34675c5f", null ],
    [ "_port", "a00026.html#a72be9a52aff8be32f6f55440b8fd1fb8", null ],
    [ "_receivers", "a00026.html#a300ac4a661b31346ab1e3046c95bac23", null ],
    [ "_senders", "a00026.html#aede19e39590bdb87d652d56080e6306a", null ]
];