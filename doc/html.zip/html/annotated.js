var annotated =
[
    [ "ultra", null, [
      [ "core", null, [
        [ "concurrent_queue", "a00003.html", "a00003" ],
        [ "ioservice_pool", "a00006.html", "a00006" ],
        [ "ordered_lock", "a00007.html", "a00007" ]
      ] ],
      [ "address", "a00001.html", "a00001" ],
      [ "address_hash", "a00002.html", "a00002" ],
      [ "execution_service", "a00004.html", "a00004" ],
      [ "function_task< Res(Args...)>", "a00005.html", "a00005" ],
      [ "scheduler", "a00008.html", "a00008" ],
      [ "task", "a00009.html", "a00009" ],
      [ "task_prio_greather", "a00010.html", "a00010" ],
      [ "task_prio_less", "a00011.html", "a00011" ]
    ] ]
];