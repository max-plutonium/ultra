var annotated =
[
    [ "google", null, [
      [ "protobuf", null, [
        [ "is_proto_enum< ::ultra::internal::scalar_message_msg_type >", "a00039.html", null ]
      ] ]
    ] ],
    [ "ultra", null, [
      [ "core", null, [
        [ "details", null, [
          [ "basic_forward_queue", "a00009.html", "a00009" ],
          [ "index_range", "a00027.html", null ],
          [ "index_range< Start >", "a00028.html", "a00028" ],
          [ "index_range< Start, Indices...>", "a00029.html", "a00029" ],
          [ "index_range_bulder", "a00030.html", "a00030" ],
          [ "index_range_bulder< Start, 0 >", "a00031.html", "a00031" ],
          [ "index_range_bulder< Start, 1 >", "a00032.html", "a00032" ],
          [ "index_sequence", "a00033.html", "a00033" ],
          [ "index_sequence_bulder", "a00034.html", "a00034" ],
          [ "index_sequence_bulder< 0 >", "a00035.html", "a00035" ],
          [ "last_index", "a00041.html", "a00041" ],
          [ "last_index< Head >", "a00042.html", "a00042" ],
          [ "return_value_setter", "a00055.html", "a00055" ]
        ] ],
        [ "action", "a00001.html", null ],
        [ "action< Res(Arguments...)>", "a00002.html", "a00002" ],
        [ "action< void(Arguments...)>", "a00003.html", "a00003" ],
        [ "action_base", "a00004.html", null ],
        [ "action_base< Res(Arguments...)>", "a00005.html", "a00005" ],
        [ "concurrent_queue", "a00010.html", null ],
        [ "curried_function", "a00011.html", null ],
        [ "curried_function< Function, BoundArgs...>", "a00012.html", "a00012" ],
        [ "execution_service", "a00015.html", "a00015" ],
        [ "fifo_scheduler", "a00018.html", "a00018" ],
        [ "grid", "a00022.html", "a00022" ],
        [ "ioservice_pool", "a00037.html", "a00037" ],
        [ "is_lockable", "a00038.html", "a00038" ],
        [ "lifo_scheduler", "a00043.html", "a00043" ],
        [ "ordered_lock", "a00047.html", null ],
        [ "prio_scheduler", "a00050.html", "a00050" ],
        [ "result", "a00052.html", "a00052" ],
        [ "result_alloc", "a00053.html", "a00053" ],
        [ "result_base", "a00054.html", "a00054" ],
        [ "scheduler", "a00059.html", "a00059" ],
        [ "system", "a00061.html", "a00061" ],
        [ "thread_pool", "a00065.html", "a00065" ],
        [ "thread_pool_base", "a00066.html", "a00066" ],
        [ "thread_worker", "a00067.html", "a00067" ]
      ] ],
      [ "internal", null, [
        [ "address", "a00006.html", "a00006" ],
        [ "scalar_message", "a00056.html", "a00056" ],
        [ "scalar_time", "a00057.html", "a00057" ],
        [ "StaticDescriptorInitializer_msg_2eproto", "a00060.html", "a00060" ],
        [ "vector_time", "a00068.html", "a00068" ]
      ] ],
      [ "address", "a00007.html", "a00007" ],
      [ "address_hash", "a00008.html", "a00008" ],
      [ "device", "a00014.html", "a00014" ],
      [ "executor", "a00016.html", "a00016" ],
      [ "field", "a00017.html", "a00017" ],
      [ "function_task", "a00021.html", "a00021" ],
      [ "interp", "a00036.html", "a00036" ],
      [ "logic_time", "a00044.html", "a00044" ],
      [ "node", "a00045.html", "a00045" ],
      [ "port", "a00048.html", "a00048" ],
      [ "port_message", "a00049.html", "a00049" ],
      [ "scalar_time", "a00058.html", "a00058" ],
      [ "task", "a00062.html", "a00062" ],
      [ "task_prio_greather", "a00063.html", "a00063" ],
      [ "task_prio_less", "a00064.html", "a00064" ],
      [ "vector_time", "a00069.html", "a00069" ],
      [ "vm", "a00070.html", "a00070" ]
    ] ]
];