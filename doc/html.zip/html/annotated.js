var annotated =
[
    [ "ultra", null, [
      [ "core", null, [
        [ "concurrent_queue", "a00003.html", "a00003" ],
        [ "fifo_scheduler", "a00005.html", "a00005" ],
        [ "ioservice_pool", "a00007.html", "a00007" ],
        [ "lifo_scheduler", "a00008.html", "a00008" ],
        [ "ordered_lock", "a00009.html", "a00009" ],
        [ "prio_scheduler", "a00010.html", "a00010" ]
      ] ],
      [ "address", "a00001.html", "a00001" ],
      [ "address_hash", "a00002.html", "a00002" ],
      [ "execution_service", "a00004.html", "a00004" ],
      [ "function_task< Res(Args...)>", "a00006.html", "a00006" ],
      [ "scheduler", "a00011.html", "a00011" ],
      [ "task", "a00012.html", "a00012" ],
      [ "task_prio_greather", "a00013.html", "a00013" ],
      [ "task_prio_less", "a00014.html", "a00014" ]
    ] ]
];