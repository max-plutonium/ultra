var annotated =
[
    [ "ultra", null, [
      [ "core", null, [
        [ "concurrent_queue", "a00003.html", "a00003" ]
      ] ],
      [ "address", "a00001.html", "a00001" ],
      [ "address_hash", "a00002.html", "a00002" ],
      [ "function_task< Res(Args...)>", "a00004.html", "a00004" ],
      [ "scheduler", "a00005.html", "a00005" ],
      [ "task", "a00006.html", "a00006" ],
      [ "task_prio_greather", "a00007.html", "a00007" ],
      [ "task_prio_less", "a00008.html", "a00008" ]
    ] ]
];