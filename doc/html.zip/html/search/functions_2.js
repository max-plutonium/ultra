var searchData=
[
  ['dequeue',['dequeue',['../a00003.html#a149286b6f792f119de7c12dd80f8099b',1,'ultra::core::concurrent_queue']]],
  ['dequeue_5funsafe',['dequeue_unsafe',['../a00003.html#a6ff3c7bed1bdc7a16880179e65fb6aa6',1,'ultra::core::concurrent_queue']]]
];
