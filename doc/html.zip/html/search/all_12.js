var searchData=
[
  ['vector_5ftime',['vector_time',['../a00068.html',1,'ultra::internal']]],
  ['vector_5ftime',['vector_time',['../a00069.html',1,'ultra']]],
  ['vm',['vm',['../a00070.html',1,'ultra']]]
];
