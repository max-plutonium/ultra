var searchData=
[
  ['queue_5fimpl',['queue_impl',['../a00051.html',1,'ultra::core::details::basic_forward_queue']]]
];
