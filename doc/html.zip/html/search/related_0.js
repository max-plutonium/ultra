var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../a00001.html#abf00afbc037b4b13fced95372ad34012',1,'ultra::address::operator&lt;&lt;()'],['../a00012.html#ae36148e42ea0308f404b5bedc3afcfc6',1,'ultra::scalar_time::operator&lt;&lt;()'],['../a00018.html#ab1dcc52c6621c5ce3b7098e3baf8d987',1,'ultra::vector_time::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../a00001.html#a2603d80d871ccc26e9b67a6be7072cee',1,'ultra::address::operator&gt;&gt;()'],['../a00012.html#a5698b53ee0eafc110f2e7897432edae1',1,'ultra::scalar_time::operator&gt;&gt;()'],['../a00018.html#a09cc64bc46859ed2fab17b803b4dbdc7',1,'ultra::vector_time::operator&gt;&gt;()']]]
];
