var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../a00007.html#abf00afbc037b4b13fced95372ad34012',1,'ultra::address']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../a00007.html#a2603d80d871ccc26e9b67a6be7072cee',1,'ultra::address']]]
];
