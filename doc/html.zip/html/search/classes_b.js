var searchData=
[
  ['ordered_5flock',['ordered_lock',['../a00047.html',1,'ultra::core']]]
];
