var searchData=
[
  ['make',['make',['../a00013.html#a63101662c4da476b916c8e8caa1fee43',1,'ultra::scheduler']]],
  ['max_5fthread_5fcount',['max_thread_count',['../a00017.html#a961f7af3259a455302b377a69135115e',1,'ultra::core::thread_pool']]],
  ['merge',['merge',['../a00012.html#af2baa1e4415adac22404ed0f49cdc499',1,'ultra::scalar_time::merge()'],['../a00018.html#a62db78d46c0b9c882edc102adfe5a822',1,'ultra::vector_time::merge()']]]
];
