var searchData=
[
  ['make',['make',['../a00008.html#a63101662c4da476b916c8e8caa1fee43',1,'ultra::scheduler']]]
];
