var searchData=
[
  ['make',['make',['../a00011.html#a63101662c4da476b916c8e8caa1fee43',1,'ultra::scheduler']]],
  ['max_5fthread_5fcount',['max_thread_count',['../a00015.html#a961f7af3259a455302b377a69135115e',1,'ultra::core::thread_pool']]]
];
