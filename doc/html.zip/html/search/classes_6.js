var searchData=
[
  ['ordered_5flock',['ordered_lock',['../a00009.html',1,'ultra::core']]]
];
