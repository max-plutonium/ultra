var searchData=
[
  ['lifo_5fscheduler',['lifo_scheduler',['../a00008.html',1,'ultra::core']]],
  ['logic_5ftime',['logic_time',['../a00009.html',1,'ultra']]]
];
