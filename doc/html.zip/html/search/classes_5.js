var searchData=
[
  ['ordered_5flock',['ordered_lock',['../a00007.html',1,'ultra::core']]]
];
