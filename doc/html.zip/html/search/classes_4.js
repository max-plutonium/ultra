var searchData=
[
  ['ioservice_5fpool',['ioservice_pool',['../a00006.html',1,'ultra::core']]]
];
