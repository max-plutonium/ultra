var searchData=
[
  ['task',['task',['../a00006.html',1,'ultra']]],
  ['task_5fprio_5fgreather',['task_prio_greather',['../a00007.html',1,'ultra']]],
  ['task_5fprio_5fless',['task_prio_less',['../a00008.html',1,'ultra']]]
];
