var searchData=
[
  ['run',['run',['../a00006.html#a62d82f5f202d5d15c468a5b8c3d02bdf',1,'ultra::task::run()'],['../a00004.html#a93b61457f6d68d6ad01bf85ff6512ea8',1,'ultra::function_task&lt; Res(Args...)&gt;::run()']]]
];
