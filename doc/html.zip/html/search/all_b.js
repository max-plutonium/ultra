var searchData=
[
  ['run',['run',['../a00006.html#a62d82f5f202d5d15c468a5b8c3d02bdf',1,'ultra::task::run()'],['../a00004.html#adb5f2d248af19febe3cb1083872e4798',1,'ultra::function_task::run()']]]
];
