var searchData=
[
  ['next_5fio_5fservice',['next_io_service',['../a00006.html#a9af5605847250c5b027af869d1209b01',1,'ultra::core::ioservice_pool']]],
  ['node',['node',['../a00001.html#ace34763d10f1aeadabe2a32d7be0160d',1,'ultra::address']]]
];
