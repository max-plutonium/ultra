var searchData=
[
  ['port',['port',['../a00048.html',1,'ultra']]],
  ['port_5fmessage',['port_message',['../a00049.html',1,'ultra']]],
  ['prio_5fscheduler',['prio_scheduler',['../a00050.html',1,'ultra::core']]]
];
