var searchData=
[
  ['release',['release',['../a00007.html#a22de117ce58a806429a33bcf74933f32',1,'ultra::core::ordered_lock']]],
  ['run',['run',['../a00009.html#a62d82f5f202d5d15c468a5b8c3d02bdf',1,'ultra::task::run()'],['../a00005.html#a93b61457f6d68d6ad01bf85ff6512ea8',1,'ultra::function_task&lt; Res(Args...)&gt;::run()']]]
];
