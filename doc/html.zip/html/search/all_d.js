var searchData=
[
  ['release',['release',['../a00009.html#a22de117ce58a806429a33bcf74933f32',1,'ultra::core::ordered_lock']]],
  ['release_5fthread',['release_thread',['../a00015.html#a14bdad803139ec6761af9fe7e6e7c238',1,'ultra::core::thread_pool']]],
  ['reserve_5fthread',['reserve_thread',['../a00015.html#af23f55c9905339121813c443a51338aa',1,'ultra::core::thread_pool']]],
  ['run',['run',['../a00012.html#a62d82f5f202d5d15c468a5b8c3d02bdf',1,'ultra::task::run()'],['../a00006.html#a93b61457f6d68d6ad01bf85ff6512ea8',1,'ultra::function_task&lt; Res(Args...)&gt;::run()']]]
];
