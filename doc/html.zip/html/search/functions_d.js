var searchData=
[
  ['_7econcurrent_5fqueue',['~concurrent_queue',['../a00003.html#af311ea247abbaa5d3b6ed435090eb367',1,'ultra::core::concurrent_queue']]],
  ['_7etask',['~task',['../a00006.html#a5c08741e1fe71688808c30142e5ab57b',1,'ultra::task']]]
];
