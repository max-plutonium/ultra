var searchData=
[
  ['task',['task',['../a00009.html#afbc5e131b9b9d412008c46e7301d9b5f',1,'ultra::task']]]
];
