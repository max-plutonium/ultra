var searchData=
[
  ['task',['task',['../a00012.html#afbc5e131b9b9d412008c46e7301d9b5f',1,'ultra::task']]],
  ['thread_5fcount',['thread_count',['../a00015.html#ab65863bb0e1c96d72ca22e269b480901',1,'ultra::core::thread_pool']]],
  ['thread_5fpool',['thread_pool',['../a00015.html#a88e8194ea6004bd12fe7d4234e79186a',1,'ultra::core::thread_pool::thread_pool(schedule_type st, std::size_t max_threads=-1)'],['../a00015.html#a0391f3f8f28091829e7219779abed394',1,'ultra::core::thread_pool::thread_pool(sched_ptr s, std::size_t max_threads=-1)']]]
];
