var searchData=
[
  ['get_5fallocator',['get_allocator',['../a00003.html#a363afa775a73e18666816e4f89e90eed',1,'ultra::core::concurrent_queue']]],
  ['get_5ffuture',['get_future',['../a00006.html#a4d65b032690a8ec45612120dbbce0c17',1,'ultra::function_task&lt; Res(Args...)&gt;']]]
];
