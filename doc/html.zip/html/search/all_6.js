var searchData=
[
  ['get_5fallocator',['get_allocator',['../a00003.html#a363afa775a73e18666816e4f89e90eed',1,'ultra::core::concurrent_queue']]],
  ['get_5ffuture',['get_future',['../a00004.html#a9e6b564b05792d3da1c196bb141daf8f',1,'ultra::function_task']]]
];
