var searchData=
[
  ['task',['task',['../a00012.html',1,'ultra']]],
  ['task',['task',['../a00012.html#afbc5e131b9b9d412008c46e7301d9b5f',1,'ultra::task']]],
  ['task_5fprio_5fgreather',['task_prio_greather',['../a00013.html',1,'ultra']]],
  ['task_5fprio_5fless',['task_prio_less',['../a00014.html',1,'ultra']]]
];
