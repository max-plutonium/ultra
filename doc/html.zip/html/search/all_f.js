var searchData=
[
  ['result',['result',['../a00052.html',1,'ultra::core']]],
  ['result_5falloc',['result_alloc',['../a00053.html',1,'ultra::core']]],
  ['result_5fbase',['result_base',['../a00054.html',1,'ultra::core']]],
  ['return_5fvalue_5fsetter',['return_value_setter',['../a00055.html',1,'ultra::core::details']]]
];
