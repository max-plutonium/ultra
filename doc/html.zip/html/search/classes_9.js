var searchData=
[
  ['task',['task',['../a00012.html',1,'ultra']]],
  ['task_5fprio_5fgreather',['task_prio_greather',['../a00013.html',1,'ultra']]],
  ['task_5fprio_5fless',['task_prio_less',['../a00014.html',1,'ultra']]]
];
