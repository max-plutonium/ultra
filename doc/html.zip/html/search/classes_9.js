var searchData=
[
  ['task',['task',['../a00014.html',1,'ultra']]],
  ['task_5fprio_5fgreather',['task_prio_greather',['../a00015.html',1,'ultra']]],
  ['task_5fprio_5fless',['task_prio_less',['../a00016.html',1,'ultra']]],
  ['thread_5fpool',['thread_pool',['../a00017.html',1,'ultra::core']]]
];
