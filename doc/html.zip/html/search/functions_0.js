var searchData=
[
  ['address',['address',['../a00007.html#a6e5ca634d9b07903177c577720b4db48',1,'ultra::address::address(int cluster, int space, int field, int node) noexcept'],['../a00007.html#a0c906d531939573a7b3bbb26a9b739e3',1,'ultra::address::address(const std::initializer_list&lt; int &gt; &amp;il)']]]
];
