var searchData=
[
  ['task',['task',['../a00009.html',1,'ultra']]],
  ['task_5fprio_5fgreather',['task_prio_greather',['../a00010.html',1,'ultra']]],
  ['task_5fprio_5fless',['task_prio_less',['../a00011.html',1,'ultra']]]
];
