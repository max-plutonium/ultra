var searchData=
[
  ['holder_5fbase',['holder_base',['../a00023.html',1,'ultra::core::action_base&lt; Res(Arguments...)&gt;']]],
  ['holder_5fdestroyer',['holder_destroyer',['../a00024.html',1,'ultra::core::action_base&lt; Res(Arguments...)&gt;']]]
];
