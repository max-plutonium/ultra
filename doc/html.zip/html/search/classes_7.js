var searchData=
[
  ['prio_5fscheduler',['prio_scheduler',['../a00011.html',1,'ultra::core']]]
];
