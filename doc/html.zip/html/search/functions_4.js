var searchData=
[
  ['field',['field',['../a00001.html#abd563f4f1453e6c238c4a9f6a0f0b769',1,'ultra::address']]],
  ['function_5ftask',['function_task',['../a00006.html#abe279003c682c6a04375e3db24d96580',1,'ultra::function_task&lt; Res(Args...)&gt;']]]
];
