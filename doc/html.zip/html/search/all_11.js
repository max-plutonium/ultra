var searchData=
[
  ['vector_5ftime',['vector_time',['../a00018.html',1,'ultra']]],
  ['vector_5ftime',['vector_time',['../a00018.html#adc00a6f9936ec8c5431be5697d4ffb5d',1,'ultra::vector_time']]]
];
