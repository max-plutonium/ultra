var searchData=
[
  ['ioservice_5fpool',['ioservice_pool',['../a00006.html',1,'ultra::core']]],
  ['ioservice_5fpool',['ioservice_pool',['../a00006.html#ab933873c52f06b26c69047b61b9912fb',1,'ultra::core::ioservice_pool']]]
];
