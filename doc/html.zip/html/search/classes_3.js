var searchData=
[
  ['deleter',['deleter',['../a00013.html',1,'ultra::core::result_base']]],
  ['device',['device',['../a00014.html',1,'ultra']]]
];
