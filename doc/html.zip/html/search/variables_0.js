var searchData=
[
  ['_5facceptor',['_acceptor',['../a00025.html#aff7c99404866785c200c0f24000e1e76',1,'ultra::vm::impl']]],
  ['_5fsignals',['_signals',['../a00025.html#af44757ce7c1ddc7364112178b084fe8c',1,'ultra::vm::impl']]]
];
