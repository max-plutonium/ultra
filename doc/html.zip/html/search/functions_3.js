var searchData=
[
  ['ioservice_5fpool',['ioservice_pool',['../a00037.html#ab933873c52f06b26c69047b61b9912fb',1,'ultra::core::ioservice_pool']]]
];
