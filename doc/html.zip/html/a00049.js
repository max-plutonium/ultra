var a00049 =
[
    [ "msg_type", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1", [
      [ "unknown", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1ab5aecfee6e7d3f331dfa72b09ed1cf9d", null ],
      [ "port_data", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1ab55ff08b0c62e3c825cc80b7967f2b2d", null ],
      [ "connect_sender", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1aa6a89616eaadfeb637b70a12a7fc2cff", null ],
      [ "connect_receiver", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1aa35725296725a3f3c2ecc13bc14cb276", null ],
      [ "disconnect_sender", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1a9273a7cbc77883a6a8d2914a0b43e28f", null ],
      [ "disconnect_receiver", "a00049.html#ac75dd6177dfb5de917ca0167c68de3f1a9256f03edfc109273f34c9ab763c5ec4", null ]
    ] ],
    [ "port_message", "a00049.html#a54fcbf0a0d0bc1d29e97c7d022da78de", null ],
    [ "port_message", "a00049.html#aef3f5ef6cb77098c86fcf2d914933bdf", null ],
    [ "data", "a00049.html#a4abb83c7dd1f4d2d87d6a3d51dea6c0e", null ],
    [ "operator!=", "a00049.html#aba06207f45e06b985ab6f0c9c8d656b1", null ],
    [ "operator==", "a00049.html#a7f3d9fa0138361159fe5861205cb1724", null ],
    [ "receiver", "a00049.html#af4dfcb4aef3a75fc9ab5c8ba1a845645", null ],
    [ "sender", "a00049.html#a129aa9acced919baaace0603347cfc13", null ],
    [ "time", "a00049.html#af6cf7bd07e0a394c00d915a282d77bc2", null ],
    [ "type", "a00049.html#ad5f7e3cbedce96d51a52473be72de0ac", null ]
];