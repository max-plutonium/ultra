var a00052 =
[
    [ "result_type", "a00052.html#a00f8a3294d0f840e584071667c3a1058", null ],
    [ "result", "a00052.html#a63aff172cadd59b5301457b83df7e0e8", null ],
    [ "~result", "a00052.html#a6c124237d16b6f48120a2792a7ee0544", null ],
    [ "result", "a00052.html#ad885475cd8b46ab550e7cfc02676aba1", null ],
    [ "get", "a00052.html#a98cb8f5dd2bb8379bbeaaae1265a92ee", null ],
    [ "isReady", "a00052.html#a1272b93061f47c3c7374bfd51894b160", null ],
    [ "set", "a00052.html#a62a4d13e0629ac54ce5001f4854fea59", null ],
    [ "set", "a00052.html#a0b580008138a2c3c0d20837e23c2a3b7", null ]
];