var hierarchy =
[
    [ "ultra::core::action<>", "a00001.html", null ],
    [ "ultra::core::action_base<>", "a00004.html", null ],
    [ "ultra::core::action_base< Res(Arguments...)>", "a00005.html", [
      [ "ultra::core::action< Res(Arguments...)>", "a00002.html", null ]
    ] ],
    [ "ultra::core::action_base< void(Arguments...)>", "a00004.html", [
      [ "ultra::core::action< void(Arguments...)>", "a00003.html", null ]
    ] ],
    [ "ultra::address", "a00007.html", null ],
    [ "ultra::address_hash", "a00008.html", null ],
    [ "Alloc", null, [
      [ "ultra::core::result_alloc< Tp, Alloc >", "a00053.html", null ]
    ] ],
    [ "ultra::core::details::basic_forward_queue< Tp, Alloc >", "a00009.html", [
      [ "ultra::core::concurrent_queue< Tp, Lock, Alloc >", "a00010.html", null ]
    ] ],
    [ "binary_function", null, [
      [ "ultra::task_prio_greather", "a00063.html", null ],
      [ "ultra::task_prio_less", "a00064.html", null ]
    ] ],
    [ "ultra::core::curried_function<>", "a00011.html", null ],
    [ "ultra::core::curried_function< Function, BoundArgs...>", "a00012.html", null ],
    [ "ultra::core::result_base::deleter", "a00013.html", null ],
    [ "enable_shared_from_this", null, [
      [ "ultra::core::thread_worker", "a00067.html", null ],
      [ "ultra::port::impl", "a00026.html", null ],
      [ "ultra::task", "a00062.html", [
        [ "ultra::device", "a00014.html", [
          [ "ultra::interp", "a00036.html", null ]
        ] ],
        [ "ultra::function_task< Callable, Args >", "a00021.html", null ]
      ] ]
    ] ],
    [ "ultra::executor", "a00016.html", [
      [ "ultra::core::execution_service", "a00015.html", [
        [ "ultra::core::thread_pool_base", "a00066.html", [
          [ "ultra::core::thread_pool< core::prio_scheduler >", "a00065.html", null ],
          [ "ultra::core::thread_pool< Scheduler >", "a00065.html", null ]
        ] ]
      ] ]
    ] ],
    [ "ultra::field", "a00017.html", null ],
    [ "ultra::core::grid< X, Y, Z, KeyXHasher, KeyYHasher, KeyXPredicate, KeyYPredicate, KeyXCompare, KeyYCompare, Allocator >", "a00022.html", null ],
    [ "ultra::core::action_base< Res(Arguments...)>::holder_base", "a00023.html", [
      [ "ultra::core::action_base< Res(Arguments...)>::function_holder< Function >", "a00019.html", null ],
      [ "ultra::core::action_base< Res(Arguments...)>::function_holder< curried_function< Function, BoundArgs...> >", "a00020.html", null ]
    ] ],
    [ "ultra::core::action_base< Res(Arguments...)>::holder_destroyer", "a00024.html", null ],
    [ "ultra::core::details::index_range< Indices >", "a00027.html", null ],
    [ "ultra::core::details::index_range< Start >", "a00028.html", null ],
    [ "ultra::core::details::index_range< Start, Indices...>", "a00029.html", null ],
    [ "ultra::core::details::index_range_bulder< Start, Num >", "a00030.html", null ],
    [ "ultra::core::details::index_range_bulder< Start, 0 >", "a00031.html", null ],
    [ "ultra::core::details::index_range_bulder< Start, 1 >", "a00032.html", null ],
    [ "ultra::core::details::index_sequence< Indices >", "a00033.html", null ],
    [ "ultra::core::details::index_sequence_bulder< Num >", "a00034.html", null ],
    [ "ultra::core::details::index_sequence_bulder< 0 >", "a00035.html", null ],
    [ "ultra::core::is_lockable< Tp >", "a00038.html", null ],
    [ "iterator", null, [
      [ "ultra::core::grid< X, Y, Z, KeyXHasher, KeyYHasher, KeyXPredicate, KeyYPredicate, KeyXCompare, KeyYCompare, Allocator >::iterator", "a00040.html", [
        [ "ultra::core::grid< X, Y, Z, KeyXHasher, KeyYHasher, KeyXPredicate, KeyYPredicate, KeyXCompare, KeyYCompare, Allocator >::x_iterator", "a00071.html", null ],
        [ "ultra::core::grid< X, Y, Z, KeyXHasher, KeyYHasher, KeyXPredicate, KeyYPredicate, KeyXCompare, KeyYCompare, Allocator >::y_iterator", "a00072.html", null ]
      ] ]
    ] ],
    [ "ultra::core::details::last_index< Head, Tail >", "a00041.html", null ],
    [ "ultra::core::details::last_index< Head >", "a00042.html", null ],
    [ "ultra::logic_time", "a00044.html", [
      [ "ultra::scalar_time", "a00058.html", null ],
      [ "ultra::vector_time", "a00069.html", null ]
    ] ],
    [ "Message", null, [
      [ "ultra::internal::address", "a00006.html", null ],
      [ "ultra::internal::scalar_message", "a00056.html", null ],
      [ "ultra::internal::scalar_time", "a00057.html", null ],
      [ "ultra::internal::vector_time", "a00068.html", null ]
    ] ],
    [ "ultra::node", "a00045.html", [
      [ "ultra::device", "a00014.html", null ],
      [ "ultra::port", "a00048.html", null ]
    ] ],
    [ "ultra::core::details::basic_forward_queue< Tp, Alloc >::node", "a00046.html", null ],
    [ "node_alloc_type", null, [
      [ "ultra::core::details::basic_forward_queue< Tp, Alloc >::queue_impl", "a00051.html", null ]
    ] ],
    [ "noncopyable", null, [
      [ "ultra::core::ioservice_pool", "a00037.html", [
        [ "ultra::vm::impl", "a00025.html", null ]
      ] ]
    ] ],
    [ "ultra::core::ordered_lock< Lockable1, Lockable2 >", "a00047.html", null ],
    [ "ultra::port_message", "a00049.html", null ],
    [ "ultra::core::result_base", "a00054.html", [
      [ "ultra::core::result< Tp >", "a00052.html", [
        [ "ultra::core::result_alloc< Tp, Alloc >", "a00053.html", null ]
      ] ]
    ] ],
    [ "ultra::core::details::return_value_setter< Tp >", "a00055.html", null ],
    [ "ultra::core::scheduler", "a00059.html", [
      [ "ultra::core::fifo_scheduler", "a00018.html", null ],
      [ "ultra::core::lifo_scheduler", "a00043.html", null ],
      [ "ultra::core::prio_scheduler", "a00050.html", null ]
    ] ],
    [ "ultra::internal::StaticDescriptorInitializer_msg_2eproto", "a00060.html", null ],
    [ "stringbuf", null, [
      [ "ultra::port::impl", "a00026.html", null ]
    ] ],
    [ "stringstream", null, [
      [ "ultra::port", "a00048.html", null ]
    ] ],
    [ "ultra::core::system", "a00061.html", null ],
    [ "true_type", null, [
      [ "google::protobuf::is_proto_enum< ::ultra::internal::scalar_message_msg_type >", "a00039.html", null ]
    ] ],
    [ "ultra::vm", "a00070.html", null ]
];