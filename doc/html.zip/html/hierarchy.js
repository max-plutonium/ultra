var hierarchy =
[
    [ "ultra::address", "a00001.html", null ],
    [ "ultra::address_hash", "a00002.html", null ],
    [ "ultra::core::concurrent_queue< Tp, Lock, Alloc >", "a00003.html", null ],
    [ "ultra::execution_service", "a00004.html", null ],
    [ "ultra::function_task< Res(Args...)>", "a00006.html", null ],
    [ "ultra::core::ioservice_pool", "a00007.html", null ],
    [ "ultra::core::ordered_lock< Lockable1, Lockable2 >", "a00009.html", null ],
    [ "ultra::scheduler", "a00011.html", [
      [ "ultra::core::fifo_scheduler", "a00005.html", null ],
      [ "ultra::core::lifo_scheduler", "a00008.html", null ],
      [ "ultra::core::prio_scheduler", "a00010.html", null ]
    ] ],
    [ "ultra::task", "a00012.html", null ],
    [ "ultra::task_prio_greather", "a00013.html", null ],
    [ "ultra::task_prio_less", "a00014.html", null ]
];