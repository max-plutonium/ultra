var hierarchy =
[
    [ "ultra::address", "a00001.html", null ],
    [ "ultra::address_hash", "a00002.html", null ],
    [ "ultra::core::concurrent_queue< Tp, Lock, Alloc >", "a00003.html", null ],
    [ "ultra::function_task< Res(Args...)>", "a00004.html", null ],
    [ "ultra::scheduler", "a00005.html", null ],
    [ "ultra::task", "a00006.html", null ],
    [ "ultra::task_prio_greather", "a00007.html", null ],
    [ "ultra::task_prio_less", "a00008.html", null ]
];