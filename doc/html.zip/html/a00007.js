var a00007 =
[
    [ "ioservice_pool", "a00007.html#ab933873c52f06b26c69047b61b9912fb", null ],
    [ "next_io_service", "a00007.html#a9af5605847250c5b027af869d1209b01", null ],
    [ "stop", "a00007.html#a3c7ad9e74994c465ab2c6b8ee898c74a", null ]
];