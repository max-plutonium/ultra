var a00012 =
[
    [ "task", "a00012.html#afbc5e131b9b9d412008c46e7301d9b5f", null ],
    [ "~task", "a00012.html#a5c08741e1fe71688808c30142e5ab57b", null ],
    [ "prio", "a00012.html#a1d48560c36ef21bdcf047d5487865d69", null ],
    [ "run", "a00012.html#a62d82f5f202d5d15c468a5b8c3d02bdf", null ],
    [ "set_prio", "a00012.html#aa6a11db7de2bc3080de0f3a3463e5ea7", null ],
    [ "task_prio_greather", "a00012.html#a5d36135bbe60783db19bf883d9c9e282", null ],
    [ "task_prio_less", "a00012.html#a66ffab00173561474c778888585ad368", null ],
    [ "_prio", "a00012.html#a6de363cfd554689e3063912187c9d59a", null ]
];