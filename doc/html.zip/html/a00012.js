var a00012 =
[
    [ "curried_function", "a00012.html#a4099e1a1925c649707b1dfec83ae4481", null ],
    [ "operator()", "a00012.html#a6a5386b60976deb79ef2cc3c77c66680", null ]
];