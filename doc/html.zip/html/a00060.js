var a00060 =
[
    [ "StaticDescriptorInitializer_msg_2eproto", "a00060.html#adcecc8cabe65df2f771e59fb9b705b75", null ]
];