var namespaces =
[
    [ "ultra", null, [
      [ "internal", null, [
        [ "anonymous_namespace{msg.pb.cc}", "a00051.html", null ]
      ] ]
    ] ]
];