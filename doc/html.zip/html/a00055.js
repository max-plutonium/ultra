var a00055 =
[
    [ "return_value_setter", "a00055.html#ab064a14d1e22bea55a5085cd09a28121", null ],
    [ "ptr", "a00055.html#ad19d7b62ee8b505d7c551bb87aaa07a8", null ]
];