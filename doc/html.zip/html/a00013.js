var a00013 =
[
    [ "operator()", "a00013.html#acc994708a9c18a3518369c34914a3f46", null ]
];