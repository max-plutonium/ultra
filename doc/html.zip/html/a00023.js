var a00023 =
[
    [ "holder_base", "a00023.html#afd28bf5e5f2fe6b67615063ee41f4618", null ],
    [ "destroy", "a00023.html#a83ff7d8fc52890c0c4a0f1e72519c2d5", null ],
    [ "invoke", "a00023.html#a8b5cd2582e5054b9e6302d5344372069", null ]
];