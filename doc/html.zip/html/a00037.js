var a00037 =
[
    [ "ioservice_pool", "a00037.html#ab933873c52f06b26c69047b61b9912fb", null ],
    [ "next_io_service", "a00037.html#a33f8db5963edce7da4d8118fc12eefa9", null ],
    [ "stop", "a00037.html#a3c7ad9e74994c465ab2c6b8ee898c74a", null ]
];