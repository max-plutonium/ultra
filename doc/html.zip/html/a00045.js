var a00045 =
[
    [ "node", "a00045.html#ae4a14d0900a2733ab2153adb946316bb", null ],
    [ "~node", "a00045.html#aa8a91bdca5bb27bf824ce9c2a641de47", null ],
    [ "_add_child", "a00045.html#a2a56984df21020e526f0facd646d653f", null ],
    [ "get_address", "a00045.html#a07d3ac0aeb255fda9cd38eabf66c743f", null ],
    [ "get_time", "a00045.html#a06871484e979a10a2e33b7b8c7f3f854", null ],
    [ "_addr", "a00045.html#a1ef7353f6a96e75367e6c5142b015129", null ],
    [ "_children", "a00045.html#a2ccf9ff7a3d82cd10b96929672688b74", null ],
    [ "_parent", "a00045.html#a1dbc16834cadd3546e9ce8511599e1ce", null ],
    [ "_time", "a00045.html#a1e475fca6bad00432f8348711d789fbe", null ]
];