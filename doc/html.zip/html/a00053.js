var a00053 =
[
    [ "allocator_type", "a00053.html#acd4a2f6b84970c31b8ec97738ca48d69", null ],
    [ "result_alloc", "a00053.html#a6d46e32f257f514e29ef5a9530fd4ee4", null ]
];