var a00061 =
[
    [ "allocate_stack", "a00061.html#a74f6f6cc3dfd9365ef36f93916023af0", null ],
    [ "current_context", "a00061.html#ab8a3d829a152fe67273a0dcfd2888705", null ],
    [ "deallocate_stack", "a00061.html#adc1ed390f66cc4a2a6281f448fc287c1", null ],
    [ "default_stacksize", "a00061.html#a0fc6eca56aab2bd5db16e03cf70d8078", null ],
    [ "fork_process", "a00061.html#a7bab8785781dff6f5705100c527de78f", null ],
    [ "get_pagecount", "a00061.html#a62d0a7a103f11f02458eb9520e110854", null ],
    [ "get_pagesize", "a00061.html#a1f6bed7077bf6dcdb4fc095771a9a83f", null ],
    [ "inside_context", "a00061.html#ac4d80f9237c5c19cba76ac4a03dffc7a", null ],
    [ "install_context", "a00061.html#a775954c46b09fa365d28d98a062dd8cf", null ],
    [ "is_stack_unbound", "a00061.html#a36352d91835152cc8903d89b65c00f3d", null ],
    [ "join_process", "a00061.html#a12d8acfe1a621f1a2f97a075510b849f", null ],
    [ "kill_process", "a00061.html#a6f51fcdc929ad5d6e5e1875ae3ad04cd", null ],
    [ "make_context", "a00061.html#a4bfaf7047098c3a1a42cca442b475312", null ],
    [ "maximum_stacksize", "a00061.html#acfed60e1e6b4306e2e5845885af98cda", null ],
    [ "minimum_stacksize", "a00061.html#a42eda15cbc6b035942e4139a701c7a37", null ],
    [ "yield_context", "a00061.html#ad0f8fa1f3763c6d38f3166a8813b82a8", null ]
];