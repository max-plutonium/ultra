var a00032 =
[
    [ "Type", "a00032.html#a018dbfec0b187ccd0549c62e189b2485", null ]
];